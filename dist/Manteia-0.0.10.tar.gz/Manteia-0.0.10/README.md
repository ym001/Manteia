Manteia - proclaim the good word
================================================================

This module proclaims the good word. May they
regain total freedom of artificial thought towards a new age
reminiscent.

You can install it with pip:

     pip install Manteia

Example of use:

     >>> from Manteia.Classification import Classification
     >>> # Initializing a list of texts,labels
     >>> documents=['a text','text b']
     >>> labels=['a','b']
     >>> Classification(documents,labels)

This code is licensed under MIT.
